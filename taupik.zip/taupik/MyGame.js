let galaxy = document.querySelector("#canvas");
let board = galaxy.getContext("2d");
let galaxyWidth = galaxy.width;
let galaxyHeight = galaxy.height;
var GameHome;
var LevelOne;
var jet;
const left = 37;
const right = 39;
const up = 38;
const down = 40;
const w = 87;
const a = 65;
const s = 83;
const d = 68;
window.addEventListener("keydown", movementCharacter);
window.addEventListener("keyup", stopmovementCharacter);
function HomeGame() {
  GameHome = new property(0, 0, 1200, 600, "Theme.png", "image");
  runningHome();
}
function runningHome() {
  this.frameNo = 0;
  this.interterval = setTimeout(MyHomeGame, 20);
}
function MyHomeGame() {
  clearMycontentGame();
  GameHome.update();
}
function PlayButton() {
  var btnplay = document.getElementById("playbtn");
  if (btnplay.style.display == "none") {
    btnplay.style.display = "block";
  } else {
    btnplay.style.display = "none";
  }
  Level1();
}

function Level1() {
  kometOne = new property(10, 10, 100, 100, "blue", "image");
  jet = new property(0, 0, 80, 120, "foto1.png", "image");
  LevelOne = new property(0, 0, 1200, 600, "yadzka.jpeg", "image");
  thegameRunning();
}

function thegameRunning() {
  //to make frame
  this.frame = 0;
  // to make looping game
  this.interterval = setInterval(MycontentGame, 20);
}

// to create all of the property
function property(x, y, width, height, color, type) {
  this.x = x;
  this.y = y;
  this.goingX = 0;
  this.goingY = 0;
  this.width = width;
  this.height = height;
  this.color = color;
  this.type = type;
  if (type == "image") {
    this.image = new Image();
    this.image.src = color;
  }
  //to update the property
  this.update = function () {
    if (type == "image") {
      board.drawImage(this.image, this.x, this.y, this.width, this.height);
    } else {
      board.fillStyle = color;
      board.fillRect(this.x, this.y, this.width, this.height);
    }
  };
  //to make the all of properti moving
  this.movement = function () {
    this.x += this.goingX;
    this.y += this.goingY;
    this.hitTop();
    this.hitBottom();
    this.hitRight();
    this.hitLeft();
  };
  this.hitTop = function () {
    var rocktop = this.height - this.height;
    if (this.y < rocktop) {
      this.y = rocktop;
    }
  };
  this.hitBottom = function () {
    var rockbottom = 600 - this.height;
    if (this.y > rockbottom) {
      this.y = rockbottom;
    }
  };
  this.hitLeft = function () {
    var rockLeft = 1200 - this.width;
    if (this.x > rockLeft) {
      this.x = rockLeft;
    }
  };

  this.hitRight = function () {
    var rockRight = this.width - this.width;
    if (this.x < rockRight) {
      this.x = rockRight;
    }
  };
}

//for clear the board
function clearMycontentGame() {
  board.clearRect(0, 0, galaxyWidth, galaxyHeight);
}

//if keyboard pressed so the player move
function movementCharacter(event) {
  const keyPressed = event.keyCode;
  if (keyPressed == left) {
    jet.goingX = -5;
  } else if (keyPressed == right) {
    jet.goingX = 5;
  } else if (keyPressed == up) {
    jet.goingY = -5;
  } else if (keyPressed == down) {
    jet.goingY = 5;
  }
}

//JIf keyboard remove so the player stop moving
function stopmovementCharacter(event) {
  const keyPressed = event.keyCode;
  if (keyPressed == left) {
    jet.goingX = 0;
  } else if (keyPressed == right) {
    jet.goingX = 0;
  } else if (keyPressed == up) {
    jet.goingY = 0;
  } else if (keyPressed == down) {
    jet.goingY = 0;
  }
}

function MycontentGame() {
  clearMycontentGame();
  LevelOne.update();
  // kometOne.update()
  // kometOne.movement()
  // kometOne.update()
  jet.movement();
  jet.update();
}
